// player.jsx — Player bar + YouTube + Audio playback engine
const { useState, useEffect, useRef, useCallback, useMemo } = React;
const { IconPlay, IconPause, IconPrev, IconNext, IconVol, IconMute, IconMusic, IconYT, IconRepeat, IconShuffle } = window.WPIcons;
const { fmtTime } = window.WP;

// ── YouTube IFrame API loader (single shared promise) ────────────────────
let _ytReady = null;
function loadYouTubeAPI() {
  if (_ytReady) return _ytReady;
  _ytReady = new Promise((resolve) => {
    if (window.YT && window.YT.Player) return resolve(window.YT);
    const tag = document.createElement('script');
    tag.src = 'https://www.youtube.com/iframe_api';
    document.head.appendChild(tag);
    window.onYouTubeIframeAPIReady = () => resolve(window.YT);
  });
  return _ytReady;
}

// ── PlayerBar — sticky bottom transport ──────────────────────────────────
function PlayerBar({
  tracks, currentId, isPlaying, position, duration, volume, muted,
  autoplay, repeat, shuffle,
  onPlayPause, onPrev, onNext, onSeek, onVolume, onToggleMute,
  onToggleAutoplay, onToggleRepeat, onToggleShuffle,
  t, dir,
}) {
  const current = tracks.find(x => x.id === currentId);
  const idx = current ? tracks.findIndex(x => x.id === currentId) : -1;

  return (
    <div className="fixed left-0 right-0 bottom-0 z-50">
      <div className="mx-auto max-w-7xl px-4 pb-4 pt-2">
        <div className="stage-card flex items-center gap-4 px-5 py-4">
          {/* Now playing */}
          <div className="flex items-center gap-3 flex-1 min-w-0">
            <div className={"nowart " + (isPlaying ? 'playing' : '')}>
              {current && current.source === 'youtube' && current.youtubeId && (
                <img
                  src={`https://i.ytimg.com/vi/${current.youtubeId}/default.jpg`}
                  alt=""
                  className="w-full h-full object-cover rounded"
                  style={{borderRadius: 4}}
                />
              )}
            </div>
            <div className="min-w-0 flex-1">
              <div className="label-tracked mb-0.5">
                {current ? t.nowPlaying : t.nothingPlaying}
              </div>
              <div className="font-cormorant text-[18px] text-ink truncate" style={{fontStyle: current ? 'normal':'italic', opacity: current ? 1 : 0.5}}>
                {current ? current.title : '—'}
              </div>
              {current && (
                <div className="flex items-center gap-2 mt-0.5">
                  {isPlaying && (
                    <span className="eq"><span/><span/><span/><span/></span>
                  )}
                  <span className="text-xs text-brownSoft" style={{letterSpacing: '0.05em'}}>
                    {idx + 1} / {tracks.length}
                  </span>
                  <span className="text-xs text-taupe">·</span>
                  <span className="chip" style={{fontSize: 8}}>
                    {current.source === 'youtube' ? t.sourceYouTube : t.sourceUpload}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Transport */}
          <div className="flex items-center gap-2">
            <button className="btn-iconic" onClick={onPrev} title="Previous" disabled={tracks.length === 0}>
              {dir === 'rtl' ? <IconNext size={16}/> : <IconPrev size={16}/>}
            </button>
            <button
              className="btn-iconic"
              onClick={onPlayPause}
              disabled={!current}
              style={{width: 50, height: 50, background: '#3A2C20', color: '#FAF5EC', borderColor: '#3A2C20'}}
              title={isPlaying ? 'Pause' : 'Play'}
            >
              {isPlaying ? <IconPause size={20}/> : <IconPlay size={20}/>}
            </button>
            <button className="btn-iconic" onClick={onNext} title="Next" disabled={tracks.length === 0}>
              {dir === 'rtl' ? <IconPrev size={16}/> : <IconNext size={16}/>}
            </button>
          </div>

          {/* Seek */}
          <div className="flex-[2] min-w-0 flex items-center gap-3 px-2">
            <span className="text-xs text-brownSoft tnum" style={{minWidth: 38, textAlign: 'right', fontVariantNumeric: 'tabular-nums', letterSpacing: '0.06em'}}>{fmtTime(position)}</span>
            <input
              type="range"
              min={0}
              max={duration && isFinite(duration) ? duration : 0}
              step={0.1}
              value={position || 0}
              onChange={(e) => onSeek(parseFloat(e.target.value))}
              disabled={!current || !duration}
              className="flex-1"
            />
            <span className="text-xs text-brownSoft tnum" style={{minWidth: 38, fontVariantNumeric: 'tabular-nums', letterSpacing: '0.06em'}}>{fmtTime(duration)}</span>
          </div>

          {/* Volume + modes */}
          <div className="flex items-center gap-2">
            <button
              className="btn-iconic"
              onClick={onToggleShuffle}
              title={t.shuffle}
              style={shuffle ? {color: '#D89274', borderColor: '#D89274'} : null}
            >
              <IconShuffle size={15}/>
            </button>
            <button
              className="btn-iconic"
              onClick={onToggleRepeat}
              title={t.repeat}
              style={repeat ? {color: '#D89274', borderColor: '#D89274'} : null}
            >
              <IconRepeat size={15}/>
            </button>
            <div className="flex items-center gap-2 px-2">
              <button className="btn-iconic" onClick={onToggleMute} title="Mute" style={{width: 32, height: 32}}>
                {muted || volume === 0 ? <IconMute size={14}/> : <IconVol size={14}/>}
              </button>
              <input
                type="range" min={0} max={1} step={0.01}
                value={muted ? 0 : volume}
                onChange={(e) => onVolume(parseFloat(e.target.value))}
                style={{width: 80}}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

window.WPPlayerBar = PlayerBar;
window.WPLoadYouTubeAPI = loadYouTubeAPI;
