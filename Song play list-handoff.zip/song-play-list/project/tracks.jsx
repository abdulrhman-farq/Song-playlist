// tracks.jsx — Track list, Add modals, Header
const { useState: useState_T, useEffect: useEffect_T, useRef: useRef_T } = React;
const {
  IconPlay: IPlay, IconPause: IPause, IconTrash, IconEdit, IconDrag,
  IconUpload, IconYT, IconImport, IconExport, IconClose, IconCheck,
  IconMusic, IconSparkle, IconGlobe, IconPlus
} = window.WPIcons;
const { fmtTime: fmtT, parseYouTubeId, ytThumb, titleFromFilename } = window.WP;

// ── Header ───────────────────────────────────────────────────────────────
function Header({ playlistName, onRename, t, dir, lang, onToggleLang, onImport, onExport, onSamples, onClearAll, hasTracks }) {
  const [editing, setEditing] = useState_T(false);
  const [draft, setDraft] = useState_T(playlistName);
  useEffect_T(() => setDraft(playlistName), [playlistName]);

  function commit() {
    const v = (draft || '').trim();
    onRename(v || t.untitled);
    setEditing(false);
  }

  return (
    <header className="relative px-8 pt-6 pb-8">
      {/* Top action bar */}
      <div className="flex justify-between items-center gap-3 mb-6 flex-wrap">
        <button
          className="btn-ghost"
          onClick={onToggleLang}
          title="Language"
          style={{gap: 6}}
        >
          <IconGlobe size={13}/>
          <span>{lang === 'ar' ? 'EN' : 'ع'}</span>
        </button>
        <div className="flex flex-wrap gap-2 justify-end">
          <button className="btn-ghost" onClick={onImport}><IconImport size={13}/><span>{t.importJson}</span></button>
          <button className="btn-ghost" onClick={onExport} disabled={!hasTracks} style={!hasTracks ? {opacity:0.4} : null}><IconExport size={13}/><span>{t.exportJson}</span></button>
          <button className="btn-ghost" onClick={onSamples}><IconSparkle size={13}/><span>{t.sample}</span></button>
          {hasTracks && (
            <button className="btn-ghost" onClick={onClearAll} style={{color:'#C97B5B', borderColor:'rgba(201,123,91,0.35)'}}><IconTrash size={13}/><span>{t.clearAll}</span></button>
          )}
        </div>
      </div>

      <div className="stack-center flex flex-col items-center gap-2">
        <div className="label-tracked">{t.eyebrow}</div>
        <div className="flex items-center gap-3">
          <img src="public/logo-mark.png" alt="" style={{width: 32, height: 32, opacity: 0.85}} />
        </div>
        <h1 className="font-italiana text-[44px] leading-none mt-1" style={{color: '#D89274', letterSpacing: '0.04em'}}>
          {t.coupleAr}
        </h1>
        <div className="font-cinzel text-[10px] mt-1" style={{letterSpacing: '0.42em', color: '#8C6A4F', textTransform: 'uppercase'}}>
          {t.coupleLatin}
        </div>
        <div className="divider-orn mt-2">
          <svg viewBox="0 0 14 14" width="10" height="10"><path d="M7 1 Q3 7 7 13 Q11 7 7 1Z" fill="#D89274"/></svg>
        </div>

        {/* Playlist title editor */}
        <div className="mt-4 flex items-center gap-2">
          <div className="label-tracked">{t.playlistLabel}</div>
        </div>
        {editing ? (
          <div className="flex items-center gap-2 mt-1">
            <input
              autoFocus
              className="input-elegant text-center"
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') commit(); if (e.key === 'Escape') setEditing(false); }}
              style={{minWidth: 280, fontFamily: dir === 'rtl' ? "'Amiri', serif" : "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: 22}}
            />
            <button className="btn-iconic" onClick={commit} title={t.save}><IconCheck size={16}/></button>
            <button className="btn-iconic" onClick={() => setEditing(false)} title={t.cancel}><IconClose size={16}/></button>
          </div>
        ) : (
          <button
            className="font-cormorant italic text-[28px] mt-1 px-3 py-1 rounded hover:bg-ivory/60 transition"
            style={{color: '#3A2C20'}}
            onClick={() => setEditing(true)}
            title={t.editTitle}
          >
            {playlistName || t.untitled}
          </button>
        )}
      </div>

    </header>
  );
}

// ── Add panel (file drop + YouTube link form) ────────────────────────────
function AddPanel({ onAddFiles, onAddYouTube, t, dir }) {
  const [dragOver, setDragOver] = useState_T(false);
  const [ytUrl, setYtUrl] = useState_T('');
  const [ytTitle, setYtTitle] = useState_T('');
  const [ytErr, setYtErr] = useState_T('');
  const fileRef = useRef_T(null);

  function onDrop(e) {
    e.preventDefault();
    setDragOver(false);
    const files = Array.from(e.dataTransfer.files || []).filter(f => f.type.startsWith('audio/') || /\.(mp3|wav|m4a|ogg|aac|flac)$/i.test(f.name));
    if (files.length) onAddFiles(files);
  }

  function submitYT() {
    setYtErr('');
    const id = parseYouTubeId(ytUrl);
    if (!id) { setYtErr('Invalid YouTube URL'); return; }
    onAddYouTube({ id, url: ytUrl.trim(), title: ytTitle.trim() });
    setYtUrl(''); setYtTitle('');
  }

  return (
    <div className="stage-card p-7 flex flex-col gap-6">
      {/* Upload zone */}
      <div>
        <div className="label-tracked mb-3">{t.addAudio}</div>
        <div
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={onDrop}
          onClick={() => fileRef.current && fileRef.current.click()}
          className="border border-dashed rounded transition cursor-pointer text-center px-6 py-9"
          style={{
            borderColor: dragOver ? '#D89274' : 'rgba(58,44,32,0.22)',
            background: dragOver ? 'rgba(216,146,116,0.08)' : 'rgba(244,236,223,0.5)',
          }}
        >
          <input
            ref={fileRef}
            type="file"
            accept="audio/*,.mp3,.wav,.m4a,.ogg,.aac,.flac"
            multiple
            className="hidden"
            onChange={(e) => {
              const files = Array.from(e.target.files || []);
              if (files.length) onAddFiles(files);
              e.target.value = '';
            }}
          />
          <div className="flex flex-col items-center gap-2">
            <div className="text-peachDeep"><IconUpload size={22}/></div>
            <div className="font-cormorant text-[19px] text-ink">{dragOver ? t.dropHere : t.chooseFiles}</div>
            <div className="text-xs text-brownSoft" style={{letterSpacing: '0.04em'}}>{t.accepted}</div>
          </div>
        </div>
      </div>

      {/* Ornament divider */}
      <div className="flex items-center justify-center">
        <div className="divider-orn">
          <svg viewBox="0 0 14 14" width="8" height="8"><path d="M7 1 Q3 7 7 13 Q11 7 7 1Z" fill="#D89274"/></svg>
        </div>
      </div>

      {/* YouTube form */}
      <div>
        <div className="label-tracked mb-3">{t.addYouTube}</div>
        <div className="flex flex-col gap-2.5">
          <input
            className="input-elegant"
            value={ytUrl}
            placeholder={t.ytPlaceholder}
            onChange={(e) => { setYtUrl(e.target.value); setYtErr(''); }}
            onKeyDown={(e) => { if (e.key === 'Enter') submitYT(); }}
            dir="ltr"
          />
          <input
            className="input-elegant"
            value={ytTitle}
            placeholder={t.titleLabel}
            onChange={(e) => setYtTitle(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') submitYT(); }}
          />
          {ytErr && <div className="text-xs" style={{color:'#C97B5B'}}>{ytErr}</div>}
          <button className="btn-primary mt-1" onClick={submitYT} style={{alignSelf: dir==='rtl' ? 'flex-start' : 'flex-end'}}>
            <IconPlus size={12}/><span>{t.add}</span>
          </button>
          <div className="text-[11px] mt-1 text-brownSoft" style={{lineHeight: 1.5}}>
            {t.youtubeNotice}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Track row ────────────────────────────────────────────────────────────
function TrackRow({ track, idx, isCurrent, isPlaying, onPlay, onDelete, onRename, onDragStart, onDragOver, onDragLeave, onDrop, dropPos, t, dir }) {
  const [editing, setEditing] = useState_T(false);
  const [draft, setDraft] = useState_T(track.title);
  useEffect_T(() => setDraft(track.title), [track.title]);

  function commit() {
    const v = (draft || '').trim();
    if (v && v !== track.title) onRename(v);
    setEditing(false);
  }

  const dropClass = dropPos === 'above' ? 'drop-above' : dropPos === 'below' ? 'drop-below' : '';

  return (
    <div
      className={"track-row group flex items-center gap-3 px-4 py-3 rounded hairline " + dropClass}
      draggable={!editing}
      onDragStart={(e) => onDragStart(e, track.id)}
      onDragOver={(e) => onDragOver(e, track.id)}
      onDragLeave={(e) => onDragLeave(e, track.id)}
      onDrop={(e) => onDrop(e, track.id)}
      style={{
        background: isCurrent ? 'linear-gradient(90deg, rgba(216,146,116,0.10), rgba(216,146,116,0.04))' : 'rgba(250,245,236,0.6)',
        borderColor: isCurrent ? 'rgba(216,146,116,0.40)' : 'rgba(58,44,32,0.10)',
      }}
    >
      {/* drag handle */}
      <div
        className="cursor-grab active:cursor-grabbing text-taupe opacity-30 group-hover:opacity-100 transition"
        title={t.dragHint}
      >
        <IconDrag size={14}/>
      </div>

      {/* index / play button */}
      <button
        onClick={() => onPlay(track.id)}
        className="relative flex items-center justify-center rounded"
        style={{width: 40, height: 40, background: 'rgba(244,236,223,0.6)', border: '0.5px solid rgba(58,44,32,0.12)'}}
        title="Play"
      >
        {isCurrent && isPlaying ? (
          <span className="eq"><span/><span/><span/><span/></span>
        ) : (
          <>
            <span className="font-cinzel text-[10px] group-hover:opacity-0 transition" style={{color: '#8C6A4F', letterSpacing: '0.1em'}}>
              {String(idx + 1).padStart(2, '0')}
            </span>
            <span className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition" style={{color: '#D89274'}}>
              <IPlay size={14}/>
            </span>
          </>
        )}
      </button>

      {/* artwork (YT thumbnail or musical note) */}
      <div className="rounded overflow-hidden flex-shrink-0" style={{width: 44, height: 44, background: 'linear-gradient(135deg, #F4ECDF 0%, #E5D5BC 100%)', border: '0.5px solid rgba(58,44,32,0.12)'}}>
        {track.source === 'youtube' && track.youtubeId ? (
          <img src={`https://i.ytimg.com/vi/${track.youtubeId}/default.jpg`} alt="" className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-brownSoft">
            <IconMusic size={18}/>
          </div>
        )}
      </div>

      {/* title + meta */}
      <div className="flex-1 min-w-0">
        {editing ? (
          <input
            autoFocus
            className="input-elegant w-full"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') commit(); if (e.key === 'Escape') setEditing(false); }}
            onBlur={commit}
            style={{padding: '6px 10px', fontSize: 16}}
          />
        ) : (
          <button
            className="font-cormorant text-[19px] truncate w-full text-left hover:text-peachDeep transition"
            style={{color: isCurrent ? '#D89274' : '#3A2C20', fontStyle: isCurrent ? 'italic' : 'normal'}}
            onDoubleClick={() => setEditing(true)}
            onClick={() => onPlay(track.id)}
            title={track.title}
          >
            {track.title}
          </button>
        )}
        <div className="flex items-center gap-2 mt-0.5">
          <span className={"chip " + (track.source === 'youtube' ? 'youtube' : 'upload')}>
            {track.source === 'youtube' ? <IconYT size={9}/> : <IconUpload size={9}/>}
            <span>{track.source === 'youtube' ? t.sourceYouTube : t.sourceUpload}</span>
          </span>
          {track.note && <span className="text-xs text-taupe italic truncate">{track.note}</span>}
        </div>
      </div>

      {/* duration */}
      <div className="text-sm text-brownSoft tnum" style={{minWidth: 50, textAlign: 'right', fontVariantNumeric: 'tabular-nums'}}>
        {fmtT(track.duration)}
      </div>

      {/* actions */}
      <div className="flex items-center gap-1 opacity-30 group-hover:opacity-100 transition">
        <button className="btn-iconic" style={{width: 32, height: 32}} onClick={() => setEditing(true)} title={t.editTitle}>
          <IconEdit size={13}/>
        </button>
        <button className="btn-iconic" style={{width: 32, height: 32, color:'#C97B5B'}} onClick={() => onDelete(track.id)} title={t.delete}>
          <IconTrash size={13}/>
        </button>
      </div>
    </div>
  );
}

window.WPHeader = Header;
window.WPAddPanel = AddPanel;
window.WPTrackRow = TrackRow;
