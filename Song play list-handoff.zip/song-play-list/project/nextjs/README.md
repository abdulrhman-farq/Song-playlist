# Wedding Playlist · رويـدا و عبدالرحمن

A bilingual (Arabic RTL + English LTR) wedding playlist app. Upload audio files
or paste YouTube links, reorder them with drag-and-drop, edit titles inline,
and play them back through a unified player.

Built with **Next.js 14 (App Router) · TypeScript · Tailwind CSS**.
Storage is purely client-side — uploaded audio lives in IndexedDB, playlist
metadata lives in localStorage. No backend required.

---

## Getting started

```bash
cd nextjs
npm install
npm run dev
```

Open <http://localhost:3000>.

### Scripts

| Command           | What it does                          |
| ----------------- | ------------------------------------- |
| `npm run dev`     | Start Next dev server on `:3000`      |
| `npm run build`   | Production build                      |
| `npm run start`   | Run the production build              |
| `npm run lint`    | Next/ESLint                           |
| `npm run typecheck` | `tsc --noEmit` for strict type pass |

---

## Project layout

```
nextjs/
├─ app/
│  ├─ globals.css        # design tokens + base styles
│  ├─ layout.tsx         # root <html> + body
│  └─ page.tsx           # main playlist screen (client component)
├─ components/
│  ├─ Header.tsx         # title, language toggle, action bar
│  ├─ AddPanel.tsx       # file drop + YouTube link form
│  ├─ TrackList.tsx      # virtual-less list with drag-and-drop reordering
│  ├─ TrackRow.tsx       # single row: thumbnail, title, chip, actions
│  ├─ PlayerBar.tsx      # sticky bottom transport
│  └─ Icons.tsx          # stroke-style icon set
├─ lib/
│  ├─ idb.ts             # IndexedDB blob store
│  ├─ storage.ts         # localStorage metadata
│  ├─ utils.ts           # id, formatters, YouTube URL parser, audio probe
│  ├─ youtube.ts         # shared YouTube IFrame API loader promise
│  ├─ i18n.ts            # AR + EN string catalogue
│  ├─ samples.ts         # 3 placeholder YouTube tracks
│  └─ usePlayer.ts       # unified playback engine (HTML5 audio + YT player)
├─ types/
│  └─ index.ts           # Track, PlaylistMeta, ExportPayload
└─ public/
   └─ logo-mark.png      # wedding monogram
```

---

## How it works

### Uploaded audio
1. The user drops or selects files (`mp3`, `wav`, `m4a`, etc.).
2. Each file is written to IndexedDB under a generated key (`b_…`).
3. Metadata is appended to the playlist (title pre-filled from filename).
4. Playback creates an Object URL from the blob and feeds it to a single
   shared `<audio>` element.

### YouTube links
1. The user pastes any common YouTube URL form — `watch?v=…`, `youtu.be/…`,
   `youtube.com/shorts/…`, `youtube.com/embed/…`, or a bare 11-char id.
2. We parse the id and store it on the track.
3. Playback uses the official **YouTube IFrame Player API** in a hidden
   iframe. The video element is offscreen; we only consume the audio. No
   download is performed and no third-party libraries are used.

#### ⚠️ YouTube limitations

- We **do not** download YouTube audio. That would violate the YouTube TOS.
- Playback requires the user's browser to be online and able to reach
  `www.youtube.com`.
- A few videos disable embedding entirely; those won't play. We surface the
  thumbnail and let the user remove them.
- Duration is unknown until the YouTube player loads — once it does, the
  track is patched with the real value.
- Background-tab playback is subject to the browser's media autoplay rules.

### Persistence

- **Metadata** (playlist name, track order, titles, settings) → `localStorage`
  under `wedding-playlist:v1`.
- **Audio blobs** → IndexedDB, database `wedding-playlist`, object store `blobs`.
- Clearing site data wipes both.

### Import / Export

- **Export** writes a JSON file containing the playlist name + every YouTube
  track. Uploaded blobs are intentionally skipped (they would not survive
  the JSON round trip; the file size would be huge).
- **Import** appends every YouTube track from the JSON file. The existing
  playlist is preserved.

---

## Customising

### Colours and fonts

Open `app/globals.css`. All colours are CSS variables under `:root`
(`--ivory`, `--peach-deep`, `--ink`, etc.). Fonts are loaded from Google
Fonts at the top of the same file. Tailwind tokens are configured in
`tailwind.config.js` if you prefer the `className` route.

### Wedding identity

Replace `public/logo-mark.png` with the couple's monogram, then edit
`lib/i18n.ts` to update the eyebrow text, Arabic names, and Latin names.
Date strings also live there.

### Sample tracks

`lib/samples.ts` ships three placeholder YouTube ids. Swap them for the
couple's actual procession / entrance / first dance picks.

---

## Deploying

This is a static-friendly Next.js app — no API routes, no server state.

- **Vercel** · push to GitHub, import in Vercel, hit deploy.
- **Netlify** · works out of the box with the Next plugin.
- **Static export** · add `output: 'export'` to `next.config.js` and run
  `next build`; the `out/` directory is fully static and can be hosted on
  any CDN (Cloudflare Pages, GitHub Pages, S3, etc.).

---

## Roadmap / next steps

These are intentionally not built in v1 — straightforward to add in Claude Code:

- Multiple named playlists, switchable from a sidebar.
- Cloud sync (e.g. Supabase) for sharing a playlist between devices.
- Crossfade between tracks.
- Equaliser / gain staging per track.
- Lyrics pane for Arabic + transliteration.
- Print-friendly setlist export (PDF).
- Mobile-optimised lock-screen media controls (Media Session API).
