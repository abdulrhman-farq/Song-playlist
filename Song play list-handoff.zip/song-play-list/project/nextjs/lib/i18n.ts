// Bilingual string catalogue. Keep keys in sync between locales.

import type { Lang, Dir } from '@/types';

type StringSet = {
  eyebrow: string;
  coupleAr: string;
  coupleLatin: string;
  subtitle: string;
  playlistLabel: string;
  untitled: string;
  addAudio: string;
  addYouTube: string;
  importJson: string;
  exportJson: string;
  sample: string;
  clearAll: string;
  tracks: string;
  track: string;
  total: string;
  nowPlaying: string;
  nothingPlaying: string;
  addFirst: string;
  emptyHint: string;
  chooseFiles: string;
  dropHere: string;
  accepted: string;
  ytTitle: string;
  ytPlaceholder: string;
  ytLabel: string;
  titleLabel: string;
  add: string;
  cancel: string;
  save: string;
  delete: string;
  rename: string;
  editTitle: string;
  confirmClear: string;
  sourceUpload: string;
  sourceYouTube: string;
  autoplay: string;
  shuffle: string;
  repeat: string;
  importErr: string;
  ytEmbedNotice: string;
  youtubeNotice: string;
  direction: Dir;
  dragHint: string;
};

export const STRINGS: Record<Lang, StringSet> = {
  en: {
    eyebrow: 'wedding playlist · 29 · 05 · 2026',
    coupleAr: 'رويـدا و عبدالرحمن',
    coupleLatin: 'Ruwaida & Abdulrahman',
    subtitle: 'A playlist for the night',
    playlistLabel: 'Playlist name',
    untitled: 'Untitled playlist',
    addAudio: 'Upload audio',
    addYouTube: 'Add YouTube',
    importJson: 'Import',
    exportJson: 'Export',
    sample: 'Load samples',
    clearAll: 'Clear all',
    tracks: 'tracks',
    track: 'track',
    total: 'Total',
    nowPlaying: 'Now playing',
    nothingPlaying: 'Nothing playing',
    addFirst: 'Start by adding music',
    emptyHint: 'Upload your favourite songs or paste YouTube links — they appear here, ready to be reordered.',
    chooseFiles: 'Choose files',
    dropHere: 'Drop audio files here',
    accepted: 'mp3, wav, m4a · stored locally on this device',
    ytTitle: 'Add a YouTube track',
    ytPlaceholder: 'https://www.youtube.com/watch?v=…',
    ytLabel: 'YouTube URL',
    titleLabel: 'Title (optional)',
    add: 'Add',
    cancel: 'Cancel',
    save: 'Save',
    delete: 'Delete',
    rename: 'Rename',
    editTitle: 'Edit title',
    confirmClear: 'Clear all tracks? This will also remove stored audio files.',
    sourceUpload: 'audio file',
    sourceYouTube: 'youtube',
    autoplay: 'Autoplay next',
    shuffle: 'Shuffle',
    repeat: 'Repeat',
    importErr: 'Could not read playlist JSON',
    ytEmbedNotice: 'YouTube tracks play through the embedded player. Duration is read once the player loads.',
    youtubeNotice: 'YouTube playback is via the official embedded player — audio is streamed, never downloaded.',
    direction: 'ltr',
    dragHint: 'Drag to reorder',
  },
  ar: {
    eyebrow: 'قائمة الزفاف · ٢٩ · ٠٥ · ٢٠٢٦',
    coupleAr: 'رويـدا و عبدالرحمن',
    coupleLatin: 'Ruwaida & Abdulrahman',
    subtitle: 'قائمة موسيقى السهرة',
    playlistLabel: 'اسم القائمة',
    untitled: 'قائمة بدون اسم',
    addAudio: 'رفع ملف صوتي',
    addYouTube: 'إضافة من يوتيوب',
    importJson: 'استيراد',
    exportJson: 'تصدير',
    sample: 'إضافة عينات',
    clearAll: 'مسح الكل',
    tracks: 'مقاطع',
    track: 'مقطع',
    total: 'المدة الكلية',
    nowPlaying: 'قيد التشغيل',
    nothingPlaying: 'لا يوجد تشغيل',
    addFirst: 'ابدأ بإضافة الموسيقى',
    emptyHint: 'ارفع ملفات الصوت أو ألصق روابط يوتيوب — ستظهر هنا جاهزة لإعادة الترتيب.',
    chooseFiles: 'اختر الملفات',
    dropHere: 'أفلت ملفات الصوت هنا',
    accepted: 'mp3 و wav و m4a · تُحفظ محلياً على جهازك',
    ytTitle: 'إضافة مقطع من يوتيوب',
    ytPlaceholder: 'https://www.youtube.com/watch?v=…',
    ytLabel: 'رابط يوتيوب',
    titleLabel: 'العنوان (اختياري)',
    add: 'إضافة',
    cancel: 'إلغاء',
    save: 'حفظ',
    delete: 'حذف',
    rename: 'إعادة تسمية',
    editTitle: 'تعديل العنوان',
    confirmClear: 'مسح جميع المقاطع؟ سيتم حذف الملفات الصوتية المخزنة أيضاً.',
    sourceUpload: 'ملف صوتي',
    sourceYouTube: 'يوتيوب',
    autoplay: 'تشغيل تلقائي',
    shuffle: 'عشوائي',
    repeat: 'تكرار',
    importErr: 'تعذّر قراءة ملف القائمة',
    ytEmbedNotice: 'مقاطع يوتيوب تُشغَّل عبر المشغّل المضمَّن. تظهر المدة بعد تحميل المشغّل.',
    youtubeNotice: 'تشغيل يوتيوب يتم عبر المشغّل الرسمي المضمَّن — يتم البث فقط، دون أي تنزيل.',
    direction: 'rtl',
    dragHint: 'اسحب لإعادة الترتيب',
  },
};

export type { StringSet };
