'use client';

// usePlayer — central playback engine.
// Manages HTML5 <audio> for uploaded blobs AND a single hidden YouTube IFrame player.
// Exposes one uniform API to the UI regardless of source.

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { Track } from '@/types';
import { getBlob } from '@/lib/idb';
import { loadYouTubeAPI } from '@/lib/youtube';

interface UsePlayerArgs {
  tracks: Track[];
  /** Called when a YouTube player first reports a real duration — lets the host patch the track. */
  onLearnedDuration?: (trackId: string, duration: number) => void;
  /** Called when current track finishes naturally (so host can decide next/repeat). */
  onTrackEnded?: () => void;
}

export interface PlayerApi {
  currentId: string | null;
  isPlaying: boolean;
  position: number;
  duration: number;
  volume: number;
  muted: boolean;
  play: (id: string) => void;
  toggle: () => void;
  stop: () => void;
  seek: (s: number) => void;
  setVolume: (v: number) => void;
  toggleMute: () => void;
  /** Host element id where the YouTube iframe mounts (hidden by CSS). */
  ytHostId: string;
}

export function usePlayer({ tracks, onLearnedDuration, onTrackEnded }: UsePlayerArgs): PlayerApi {
  const [currentId, setCurrentId] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [position, setPosition]   = useState(0);
  const [duration, setDuration]   = useState(0);
  const [volume, setVolumeState]  = useState(0.8);
  const [muted, setMuted]         = useState(false);

  const audioRef    = useRef<HTMLAudioElement | null>(null);
  const ytPlayerRef = useRef<any>(null);
  const ytPollRef   = useRef<number | null>(null);
  const urlCacheRef = useRef<Record<string, string>>({}); // blobKey -> objectURL
  const tracksRef   = useRef<Track[]>(tracks);
  useEffect(() => { tracksRef.current = tracks; }, [tracks]);

  // Resolve / cache object URL for an upload
  const getAudioUrl = useCallback(async (track: Track): Promise<string | null> => {
    if (track.source !== 'upload') return null;
    const cached = urlCacheRef.current[track.blobKey];
    if (cached) return cached;
    const blob = await getBlob(track.blobKey);
    if (!blob) return null;
    const url = URL.createObjectURL(blob);
    urlCacheRef.current[track.blobKey] = url;
    return url;
  }, []);

  // Lazy-create the <audio> element on first mount.
  useEffect(() => {
    if (audioRef.current) return;
    const a = new Audio();
    a.preload = 'metadata';
    a.addEventListener('timeupdate', () => setPosition(a.currentTime));
    a.addEventListener('loadedmetadata', () => {
      const d = a.duration;
      if (isFinite(d)) {
        setDuration(d);
        const id = currentIdRef.current;
        if (id) onLearnedDurationRef.current?.(id, d);
      }
    });
    a.addEventListener('play',  () => setIsPlaying(true));
    a.addEventListener('pause', () => setIsPlaying(false));
    a.addEventListener('ended', () => onTrackEndedRef.current?.());
    audioRef.current = a;

    return () => {
      Object.values(urlCacheRef.current).forEach(URL.revokeObjectURL);
      urlCacheRef.current = {};
    };
  }, []);

  // Keep latest callbacks/state behind refs so listeners stay stable.
  const currentIdRef         = useRef<string | null>(null);
  const onLearnedDurationRef = useRef(onLearnedDuration);
  const onTrackEndedRef      = useRef(onTrackEnded);
  useEffect(() => { currentIdRef.current = currentId; }, [currentId]);
  useEffect(() => { onLearnedDurationRef.current = onLearnedDuration; }, [onLearnedDuration]);
  useEffect(() => { onTrackEndedRef.current = onTrackEnded; }, [onTrackEnded]);

  function startYTPoll() {
    if (ytPollRef.current) window.clearInterval(ytPollRef.current);
    ytPollRef.current = window.setInterval(() => {
      const p = ytPlayerRef.current;
      if (!p || typeof p.getCurrentTime !== 'function') return;
      try {
        setPosition(p.getCurrentTime() || 0);
        const d = p.getDuration();
        if (d) setDuration(d);
      } catch { /* player not ready */ }
    }, 400);
  }

  function stopYTPoll() {
    if (ytPollRef.current) {
      window.clearInterval(ytPollRef.current);
      ytPollRef.current = null;
    }
  }

  // ── Effect: load whichever source matches currentId ─────────────────────
  useEffect(() => {
    if (!currentId) return;
    const track = tracksRef.current.find(t => t.id === currentId);
    if (!track) return;

    // Tear down previous transport.
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.removeAttribute('src');
      audioRef.current.load();
    }
    if (ytPlayerRef.current?.stopVideo) {
      try { ytPlayerRef.current.stopVideo(); } catch { /* ignore */ }
    }
    stopYTPoll();
    setPosition(0);
    setDuration(0);

    if (track.source === 'upload') {
      (async () => {
        const url = await getAudioUrl(track);
        const a = audioRef.current;
        if (!url || !a) { setIsPlaying(false); return; }
        a.src = url;
        a.volume = muted ? 0 : volume;
        try { await a.play(); setIsPlaying(true); }
        catch { setIsPlaying(false); }
      })();
    } else {
      (async () => {
        const YT = await loadYouTubeAPI();
        if (!ytPlayerRef.current) {
          ytPlayerRef.current = new YT.Player('wp-yt-host', {
            height: '1', width: '1',
            videoId: track.youtubeId,
            playerVars: { autoplay: 1, controls: 0, modestbranding: 1, rel: 0, playsinline: 1 },
            events: {
              onReady: (e: any) => {
                e.target.setVolume(Math.round((muted ? 0 : volume) * 100));
                e.target.playVideo();
                startYTPoll();
              },
              onStateChange: (e: any) => {
                if (e.data === YT.PlayerState.PLAYING) setIsPlaying(true);
                else if (e.data === YT.PlayerState.PAUSED) setIsPlaying(false);
                else if (e.data === YT.PlayerState.ENDED) onTrackEndedRef.current?.();
                if (e.data === YT.PlayerState.PLAYING || e.data === YT.PlayerState.BUFFERING) {
                  const d = e.target.getDuration();
                  if (d) {
                    setDuration(d);
                    const id = currentIdRef.current;
                    if (id) onLearnedDurationRef.current?.(id, d);
                  }
                }
              },
            },
          });
        } else {
          ytPlayerRef.current.loadVideoById(track.youtubeId);
          ytPlayerRef.current.setVolume(Math.round((muted ? 0 : volume) * 100));
          startYTPoll();
        }
      })();
    }
    // Intentionally omit volume/muted from deps — handled below.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentId]);

  // Volume / mute sync (live, not on track change)
  useEffect(() => {
    const v = muted ? 0 : volume;
    if (audioRef.current) audioRef.current.volume = v;
    if (ytPlayerRef.current?.setVolume) {
      try { ytPlayerRef.current.setVolume(Math.round(v * 100)); } catch { /* */ }
    }
  }, [volume, muted]);

  // ── Public API ──────────────────────────────────────────────────────────
  const play = useCallback((id: string) => {
    if (id === currentIdRef.current) {
      toggleRef.current?.();
    } else {
      setCurrentId(id);
    }
  }, []);

  const toggle = useCallback(() => {
    const id = currentIdRef.current;
    if (!id) {
      const first = tracksRef.current[0];
      if (first) setCurrentId(first.id);
      return;
    }
    const track = tracksRef.current.find(t => t.id === id);
    if (!track) return;
    if (track.source === 'upload') {
      const a = audioRef.current!;
      if (a.paused) a.play().catch(() => { /* */ });
      else a.pause();
    } else {
      const p = ytPlayerRef.current;
      if (!p) return;
      const state = p.getPlayerState?.();
      if (state === 1) p.pauseVideo(); else p.playVideo();
    }
  }, []);

  const toggleRef = useRef(toggle);
  useEffect(() => { toggleRef.current = toggle; }, [toggle]);

  const stop = useCallback(() => {
    if (audioRef.current) { audioRef.current.pause(); audioRef.current.removeAttribute('src'); audioRef.current.load(); }
    if (ytPlayerRef.current?.stopVideo) { try { ytPlayerRef.current.stopVideo(); } catch { /* */ } }
    stopYTPoll();
    setIsPlaying(false);
    setPosition(0);
    setDuration(0);
    setCurrentId(null);
  }, []);

  const seek = useCallback((s: number) => {
    setPosition(s);
    const id = currentIdRef.current;
    if (!id) return;
    const track = tracksRef.current.find(t => t.id === id);
    if (!track) return;
    if (track.source === 'upload') {
      const a = audioRef.current!;
      a.currentTime = s;
    } else {
      try { ytPlayerRef.current?.seekTo(s, true); } catch { /* */ }
    }
  }, []);

  const setVolume = useCallback((v: number) => {
    setVolumeState(Math.max(0, Math.min(1, v)));
    setMuted(false);
  }, []);

  const toggleMute = useCallback(() => setMuted(m => !m), []);

  return useMemo<PlayerApi>(() => ({
    currentId, isPlaying, position, duration,
    volume, muted,
    play, toggle, stop, seek, setVolume, toggleMute,
    ytHostId: 'wp-yt-host',
  }), [currentId, isPlaying, position, duration, volume, muted, play, toggle, stop, seek, setVolume, toggleMute]);
}
