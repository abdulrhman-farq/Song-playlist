// localStorage persistence for playlist metadata.

import type { PlaylistMeta } from '@/types';

const META_KEY = 'wedding-playlist:v1';

export function loadMeta(): PlaylistMeta | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = window.localStorage.getItem(META_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as PlaylistMeta;
  } catch {
    return null;
  }
}

export function saveMeta(meta: PlaylistMeta): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(META_KEY, JSON.stringify(meta));
  } catch {
    /* quota or serialization failure — silent */
  }
}

export function clearMeta(): void {
  if (typeof window === 'undefined') return;
  window.localStorage.removeItem(META_KEY);
}
