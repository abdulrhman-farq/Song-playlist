// Pure helpers: id, formatting, YouTube URL parsing, audio probing.

export function uid(): string {
  return 't_' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}

export function fmtTime(sec: number | null | undefined): string {
  if (sec == null || isNaN(sec) || !isFinite(sec)) return '—:—';
  const s = Math.max(0, Math.floor(sec));
  const m = Math.floor(s / 60);
  return `${m}:${String(s % 60).padStart(2, '0')}`;
}

/** Accept any common YouTube URL form (watch / youtu.be / shorts / embed / bare id). */
export function parseYouTubeId(url: string): string | null {
  if (!url) return null;
  const trimmed = url.trim();
  if (/^[A-Za-z0-9_-]{11}$/.test(trimmed)) return trimmed;
  try {
    const u = new URL(trimmed);
    if (u.hostname.includes('youtu.be')) {
      const id = u.pathname.replace(/^\//, '').split('/')[0];
      return /^[A-Za-z0-9_-]{11}$/.test(id) ? id : null;
    }
    if (u.hostname.includes('youtube.com') || u.hostname.includes('music.youtube.com')) {
      const v = u.searchParams.get('v');
      if (v && /^[A-Za-z0-9_-]{11}$/.test(v)) return v;
      const m = u.pathname.match(/\/(embed|shorts)\/([A-Za-z0-9_-]{11})/);
      if (m) return m[2];
    }
  } catch {
    /* not a URL */
  }
  return null;
}

export function ytThumb(id: string, size: 'default' | 'hq' = 'default'): string {
  return `https://i.ytimg.com/vi/${id}/${size === 'hq' ? 'hqdefault' : 'default'}.jpg`;
}

export function titleFromFilename(name: string): string {
  if (!name) return 'Untitled';
  return name.replace(/\.[^.]+$/, '').replace(/[_\-]+/g, ' ').trim() || 'Untitled';
}

/** Read audio metadata duration in the background. Resolves null on failure. */
export function probeAudioDuration(blob: Blob): Promise<number | null> {
  return new Promise((resolve) => {
    if (typeof window === 'undefined') { resolve(null); return; }
    const url = URL.createObjectURL(blob);
    const a = new Audio();
    a.preload = 'metadata';
    a.src = url;
    const done = (val: number | null) => { URL.revokeObjectURL(url); resolve(val); };
    a.onloadedmetadata = () => done(isFinite(a.duration) ? a.duration : null);
    a.onerror = () => done(null);
    window.setTimeout(() => done(null), 8000);
  });
}
