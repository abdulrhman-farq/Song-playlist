// Domain types for the wedding playlist app.

export type TrackSource = 'upload' | 'youtube';

export interface BaseTrack {
  id: string;
  title: string;
  source: TrackSource;
  /** Duration in seconds. Null when unknown (YouTube before load). */
  duration: number | null;
  /** Optional free-form note (filename, "sample · classical", etc.) */
  note?: string;
}

export interface UploadTrack extends BaseTrack {
  source: 'upload';
  /** Key into IndexedDB `blobs` store. */
  blobKey: string;
  /** Original filename, preserved for reference. */
  blobName: string;
}

export interface YouTubeTrack extends BaseTrack {
  source: 'youtube';
  /** 11-character YouTube video id. */
  youtubeId: string;
  /** Original URL the user pasted (for re-export). */
  url: string;
}

export type Track = UploadTrack | YouTubeTrack;

export interface PlaylistMeta {
  name: string;
  tracks: Track[];
  volume: number;
  autoplay: boolean;
  shuffle: boolean;
  repeat: boolean;
}

/** Shape of an exported / imported JSON playlist. */
export interface ExportPayload {
  _meta: { app: 'wedding-playlist'; version: number; exportedAt: string };
  name: string;
  /** Only YouTube tracks survive round-trip — uploaded blobs can't travel. */
  tracks: Array<Pick<YouTubeTrack, 'id' | 'source' | 'title' | 'youtubeId' | 'url' | 'duration' | 'note'>>;
  stats: { uploadedSkipped: number };
}

export type Lang = 'ar' | 'en';
export type Dir  = 'ltr' | 'rtl';
