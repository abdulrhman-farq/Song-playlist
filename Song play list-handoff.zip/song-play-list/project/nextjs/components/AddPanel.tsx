'use client';

import { useRef, useState } from 'react';
import type { StringSet } from '@/lib/i18n';
import { parseYouTubeId } from '@/lib/utils';
import { IconPlus, IconUpload } from './Icons';

interface Props {
  onAddFiles: (files: File[]) => void;
  onAddYouTube: (data: { id: string; url: string; title: string }) => void;
  t: StringSet;
}

export default function AddPanel({ onAddFiles, onAddYouTube, t }: Props) {
  const [dragOver, setDragOver] = useState(false);
  const [ytUrl, setYtUrl]       = useState('');
  const [ytTitle, setYtTitle]   = useState('');
  const [ytErr, setYtErr]       = useState('');
  const fileRef                 = useRef<HTMLInputElement | null>(null);

  const dir = t.direction;

  function onDrop(e: React.DragEvent) {
    e.preventDefault();
    setDragOver(false);
    const files = Array.from(e.dataTransfer.files || [])
      .filter(f => f.type.startsWith('audio/') || /\.(mp3|wav|m4a|ogg|aac|flac)$/i.test(f.name));
    if (files.length) onAddFiles(files);
  }

  function submitYT() {
    setYtErr('');
    const id = parseYouTubeId(ytUrl);
    if (!id) { setYtErr('Invalid YouTube URL'); return; }
    onAddYouTube({ id, url: ytUrl.trim(), title: ytTitle.trim() });
    setYtUrl(''); setYtTitle('');
  }

  return (
    <div className="stage-card p-7 flex flex-col gap-6">
      {/* Upload zone */}
      <div>
        <div className="label-tracked mb-3">{t.addAudio}</div>
        <div
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={onDrop}
          onClick={() => fileRef.current?.click()}
          className="border border-dashed rounded transition cursor-pointer text-center px-6 py-9"
          style={{
            borderColor: dragOver ? '#D89274' : 'rgba(58,44,32,0.22)',
            background:  dragOver ? 'rgba(216,146,116,0.08)' : 'rgba(244,236,223,0.5)',
          }}
        >
          <input
            ref={fileRef}
            type="file"
            accept="audio/*,.mp3,.wav,.m4a,.ogg,.aac,.flac"
            multiple
            className="hidden"
            onChange={(e) => {
              const files = Array.from(e.target.files || []);
              if (files.length) onAddFiles(files);
              if (e.target) e.target.value = '';
            }}
          />
          <div className="flex flex-col items-center gap-2">
            <div style={{ color: '#D89274' }}><IconUpload size={22} /></div>
            <div className="font-cormorant text-[19px]" style={{ color: '#3A2C20' }}>
              {dragOver ? t.dropHere : t.chooseFiles}
            </div>
            <div className="text-xs" style={{ color: '#8C6A4F', letterSpacing: '0.04em' }}>
              {t.accepted}
            </div>
          </div>
        </div>
      </div>

      {/* Ornament divider */}
      <div className="flex items-center justify-center">
        <div className="divider-orn">
          <svg viewBox="0 0 14 14" width="8" height="8">
            <path d="M7 1 Q3 7 7 13 Q11 7 7 1Z" fill="#D89274" />
          </svg>
        </div>
      </div>

      {/* YouTube */}
      <div>
        <div className="label-tracked mb-3">{t.addYouTube}</div>
        <div className="flex flex-col gap-2.5">
          <input
            className="input-elegant"
            value={ytUrl}
            placeholder={t.ytPlaceholder}
            onChange={(e) => { setYtUrl(e.target.value); setYtErr(''); }}
            onKeyDown={(e) => { if (e.key === 'Enter') submitYT(); }}
            dir="ltr"
          />
          <input
            className="input-elegant"
            value={ytTitle}
            placeholder={t.titleLabel}
            onChange={(e) => setYtTitle(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') submitYT(); }}
          />
          {ytErr && <div className="text-xs" style={{ color: '#C97B5B' }}>{ytErr}</div>}
          <button
            className="btn-primary mt-1"
            onClick={submitYT}
            style={{ alignSelf: dir === 'rtl' ? 'flex-start' : 'flex-end' }}
          >
            <IconPlus size={12} /><span>{t.add}</span>
          </button>
          <div className="text-[11px] mt-1" style={{ color: '#8C6A4F', lineHeight: 1.5 }}>
            {t.youtubeNotice}
          </div>
        </div>
      </div>
    </div>
  );
}
