'use client';

import { useRef, useState } from 'react';
import type { Track } from '@/types';
import type { StringSet } from '@/lib/i18n';
import { fmtTime } from '@/lib/utils';
import TrackRow from './TrackRow';

interface Props {
  tracks: Track[];
  currentId: string | null;
  isPlaying: boolean;
  onPlay: (id: string) => void;
  onDelete: (id: string) => void;
  onRename: (id: string, title: string) => void;
  onReorder: (fromId: string, toId: string, pos: 'above' | 'below') => void;
  t: StringSet;
}

export default function TrackList({
  tracks, currentId, isPlaying,
  onPlay, onDelete, onRename, onReorder, t,
}: Props) {
  const [dragOverId, setDragOverId] = useState<string | null>(null);
  const [dropPos, setDropPos]       = useState<'above' | 'below' | null>(null);
  const dragId = useRef<string | null>(null);

  const total = tracks.reduce((s, x) => s + (typeof x.duration === 'number' && isFinite(x.duration) ? x.duration : 0), 0);

  function onDragStart(e: React.DragEvent, id: string) {
    dragId.current = id;
    e.dataTransfer.effectAllowed = 'move';
    try { e.dataTransfer.setData('text/plain', id); } catch { /* */ }
  }
  function onDragOver(e: React.DragEvent, id: string) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const above = (e.clientY - rect.top) < rect.height / 2;
    setDragOverId(id);
    setDropPos(above ? 'above' : 'below');
  }
  function onDragLeave(_e: React.DragEvent, id: string) {
    if (dragOverId === id) { setDragOverId(null); setDropPos(null); }
  }
  function onDrop(e: React.DragEvent, id: string) {
    e.preventDefault();
    const from = dragId.current;
    if (from && from !== id && dropPos) onReorder(from, id, dropPos);
    dragId.current = null;
    setDragOverId(null); setDropPos(null);
  }

  return (
    <div className="stage-card p-6">
      <div className="flex items-baseline justify-between mb-4 px-1">
        <div className="label-tracked">
          {tracks.length} {tracks.length === 1 ? t.track : t.tracks}
        </div>
        <div className="label-tracked">
          {t.total} ·{' '}
          <span className="tnum" style={{ fontVariantNumeric: 'tabular-nums', color: '#3A2C20' }}>
            {fmtTime(total)}
          </span>
        </div>
      </div>

      {tracks.length === 0 ? (
        <div className="text-center py-16 px-6">
          <div className="inline-flex items-center justify-center rounded-full mb-4"
               style={{ width: 72, height: 72, background: 'rgba(216,146,116,0.10)', border: '0.5px solid rgba(216,146,116,0.30)' }}>
            <span style={{ color: '#D89274' }}>♪</span>
          </div>
          <div className="font-italiana text-[28px]" style={{ color: '#D89274' }}>{t.addFirst}</div>
          <div className="font-cormorant text-[16px] mt-2 max-w-md mx-auto"
               style={{ color: '#6B4A35', lineHeight: 1.5, fontStyle: 'italic' }}>
            {t.emptyHint}
          </div>
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          {tracks.map((tr, i) => (
            <TrackRow
              key={tr.id}
              track={tr} idx={i}
              isCurrent={tr.id === currentId}
              isPlaying={tr.id === currentId && isPlaying}
              onPlay={onPlay}
              onDelete={onDelete}
              onRename={onRename}
              onDragStart={onDragStart}
              onDragOver={onDragOver}
              onDragLeave={onDragLeave}
              onDrop={onDrop}
              dropPos={dragOverId === tr.id ? dropPos : null}
              t={t}
            />
          ))}
        </div>
      )}
    </div>
  );
}
