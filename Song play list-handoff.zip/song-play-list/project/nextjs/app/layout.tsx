import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Wedding Playlist · رويدا و عبدالرحمن',
  description: 'A bilingual wedding playlist with uploads and YouTube embeds.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  // Direction is finalised client-side via <html lang dir> updates inside the page.
  return (
    <html lang="en" dir="ltr">
      <body>{children}</body>
    </html>
  );
}
