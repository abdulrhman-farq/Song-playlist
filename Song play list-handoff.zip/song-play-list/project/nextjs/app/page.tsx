'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { ExportPayload, Lang, Track, UploadTrack, YouTubeTrack } from '@/types';
import { clearBlobs, deleteBlob, putBlob } from '@/lib/idb';
import { loadMeta, saveMeta } from '@/lib/storage';
import { fmtTime, probeAudioDuration, titleFromFilename, uid } from '@/lib/utils';
import { STRINGS } from '@/lib/i18n';
import { makeSamples } from '@/lib/samples';
import { usePlayer } from '@/lib/usePlayer';

import Header from '@/components/Header';
import AddPanel from '@/components/AddPanel';
import TrackList from '@/components/TrackList';
import PlayerBar from '@/components/PlayerBar';

export default function HomePage() {
  // ── Language / direction ────────────────────────────────────────────────
  const [lang, setLang] = useState<Lang>('en');
  const [hydrated, setHydrated] = useState(false);

  // Read saved language + meta once mounted (avoids SSR mismatch).
  useEffect(() => {
    const saved = window.localStorage.getItem('wp:lang') as Lang | null;
    if (saved === 'ar' || saved === 'en') setLang(saved);

    const meta = loadMeta();
    if (meta) {
      setPlaylistName(meta.name || STRINGS[saved || 'en'].untitled);
      setTracks(Array.isArray(meta.tracks) ? meta.tracks : []);
      if (typeof meta.volume === 'number') setVolumeInit(meta.volume);
      if (typeof meta.autoplay === 'boolean') setAutoplay(meta.autoplay);
      if (typeof meta.shuffle === 'boolean') setShuffle(meta.shuffle);
      if (typeof meta.repeat === 'boolean') setRepeat(meta.repeat);
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    document.documentElement.lang = lang;
    document.documentElement.dir = STRINGS[lang].direction;
    window.localStorage.setItem('wp:lang', lang);
  }, [lang, hydrated]);

  const t = STRINGS[lang];

  // ── Playlist state ──────────────────────────────────────────────────────
  const [playlistName, setPlaylistName] = useState<string>(t.untitled);
  const [tracks, setTracks]             = useState<Track[]>([]);
  const [autoplay, setAutoplay]         = useState(true);
  const [shuffle, setShuffle]           = useState(false);
  const [repeat, setRepeat]             = useState(false);
  const [toast, setToast]               = useState<string | null>(null);
  const [volumeInit, setVolumeInit]     = useState(0.8);

  // ── Player ──────────────────────────────────────────────────────────────
  const handleEnded = useCallback(() => {
    if (repeat) {
      // re-seek to 0 + play
      player.seek(0);
      player.toggle();
      return;
    }
    if (autoplay) goNext();
  }, [autoplay, repeat]); // player ref captured below

  const player = usePlayer({
    tracks,
    onLearnedDuration: (id, d) =>
      setTracks(prev => prev.map(x => (x.id === id && !x.duration ? { ...x, duration: d } : x))),
    onTrackEnded: () => handleEnded(),
  });

  // Apply saved volume once hydrated.
  const appliedVolume = useRef(false);
  useEffect(() => {
    if (!hydrated || appliedVolume.current) return;
    player.setVolume(volumeInit);
    appliedVolume.current = true;
  }, [hydrated, volumeInit, player]);

  // ── Persist metadata ────────────────────────────────────────────────────
  useEffect(() => {
    if (!hydrated) return;
    saveMeta({
      name: playlistName,
      tracks,
      volume: player.volume,
      autoplay, shuffle, repeat,
    });
  }, [hydrated, playlistName, tracks, player.volume, autoplay, shuffle, repeat]);

  // ── Toast ───────────────────────────────────────────────────────────────
  function flash(msg: string) {
    setToast(msg);
    window.clearTimeout((flash as any)._t);
    (flash as any)._t = window.setTimeout(() => setToast(null), 2200);
  }

  // ── Mutations ───────────────────────────────────────────────────────────
  async function handleAddFiles(files: File[]) {
    const added: UploadTrack[] = [];
    for (const file of files) {
      const blobKey = 'b_' + uid();
      await putBlob(blobKey, file);
      const dur = await probeAudioDuration(file);
      added.push({
        id: uid(),
        source: 'upload',
        title: titleFromFilename(file.name),
        blobKey, blobName: file.name,
        duration: dur,
        note: file.name,
      });
    }
    setTracks(prev => [...prev, ...added]);
    flash(`+ ${added.length} ${added.length === 1 ? t.track : t.tracks}`);
  }

  function handleAddYouTube({ id, url, title }: { id: string; url: string; title: string }) {
    const yt: YouTubeTrack = {
      id: uid(),
      source: 'youtube',
      title: title || `YouTube · ${id}`,
      youtubeId: id,
      url,
      duration: null,
    };
    setTracks(prev => [...prev, yt]);
    flash('+ ' + (title || 'YouTube'));
  }

  function handleLoadSamples() {
    const s = makeSamples();
    setTracks(prev => [...prev, ...s]);
    flash(`+ ${s.length} ${t.tracks}`);
  }

  async function handleDelete(id: string) {
    const tr = tracks.find(x => x.id === id);
    if (tr?.source === 'upload') {
      await deleteBlob(tr.blobKey).catch(() => undefined);
    }
    setTracks(prev => prev.filter(x => x.id !== id));
    if (player.currentId === id) player.stop();
  }

  function handleRename(id: string, title: string) {
    setTracks(prev => prev.map(x => (x.id === id ? { ...x, title } : x)));
  }

  function handleReorder(fromId: string, toId: string, pos: 'above' | 'below') {
    setTracks(prev => {
      const from = prev.findIndex(x => x.id === fromId);
      if (from < 0) return prev;
      const next = prev.slice();
      const [moved] = next.splice(from, 1);
      let to = next.findIndex(x => x.id === toId);
      if (to < 0) return prev;
      if (pos === 'below') to += 1;
      next.splice(to, 0, moved);
      return next;
    });
  }

  async function handleClearAll() {
    if (!window.confirm(t.confirmClear)) return;
    await clearBlobs();
    player.stop();
    setTracks([]);
  }

  // ── Import / export ─────────────────────────────────────────────────────
  function handleExport() {
    const payload: ExportPayload = {
      _meta: { app: 'wedding-playlist', version: 1, exportedAt: new Date().toISOString() },
      name: playlistName,
      tracks: tracks
        .filter((x): x is YouTubeTrack => x.source === 'youtube')
        .map(x => ({
          id: x.id, source: 'youtube', title: x.title,
          youtubeId: x.youtubeId, url: x.url, duration: x.duration, note: x.note,
        })),
      stats: { uploadedSkipped: tracks.filter(x => x.source === 'upload').length },
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = (playlistName || 'wedding-playlist').replace(/[^\w\u0600-\u06FF\-]+/g, '_') + '.json';
    a.click();
    URL.revokeObjectURL(url);
    flash('JSON exported');
  }

  function handleImport() {
    const inp = document.createElement('input');
    inp.type = 'file';
    inp.accept = 'application/json,.json';
    inp.onchange = async () => {
      const f = inp.files?.[0];
      if (!f) return;
      try {
        const data = JSON.parse(await f.text()) as Partial<ExportPayload>;
        if (data.name) setPlaylistName(data.name);
        if (Array.isArray(data.tracks)) {
          const incoming: YouTubeTrack[] = data.tracks
            .filter(x => x.source === 'youtube' && x.youtubeId)
            .map(x => ({
              id: uid(),
              source: 'youtube',
              title: x.title || 'Untitled',
              youtubeId: x.youtubeId!,
              url: x.url || `https://www.youtube.com/watch?v=${x.youtubeId}`,
              duration: x.duration ?? null,
              note: x.note,
            }));
          setTracks(prev => [...prev, ...incoming]);
          flash(`+ ${incoming.length} ${t.tracks}`);
        }
      } catch {
        window.alert(t.importErr);
      }
    };
    inp.click();
  }

  // ── Transport ──────────────────────────────────────────────────────────
  function indexOf(id: string | null) { return tracks.findIndex(x => x.id === id); }
  function pickNext(dir: 1 | -1) {
    const i = indexOf(player.currentId);
    if (tracks.length === 0) return -1;
    if (shuffle && dir > 0) {
      if (tracks.length === 1) return 0;
      let n: number;
      do { n = Math.floor(Math.random() * tracks.length); } while (n === i);
      return n;
    }
    let n = i + dir;
    if (n < 0) n = tracks.length - 1;
    if (n >= tracks.length) n = 0;
    return n;
  }
  function goNext() {
    const n = pickNext(1);
    if (n >= 0) player.play(tracks[n].id);
  }
  function goPrev() {
    const n = pickNext(-1);
    if (n >= 0) player.play(tracks[n].id);
  }

  // ── Render ─────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen relative">
      <div
        className="fixed inset-0"
        style={{ background: 'radial-gradient(ellipse 80% 50% at 50% 0%, #F4ECDF 0%, #EBE0CE 50%, #E5D5BC 100%)' }}
      />

      <div className="relative">
        <div className="mx-auto max-w-7xl px-6 py-8" style={{ paddingBottom: 140 }}>
          <div className="stage-card paper-bg p-2">
            <div style={{ position: 'relative', zIndex: 1 }}>
              <Header
                playlistName={playlistName}
                onRename={setPlaylistName}
                t={t} lang={lang}
                onToggleLang={() => setLang(l => (l === 'ar' ? 'en' : 'ar'))}
                onImport={handleImport}
                onExport={handleExport}
                onSamples={handleLoadSamples}
                onClearAll={handleClearAll}
                hasTracks={tracks.length > 0}
              />

              <div className="px-8 pb-8 grid grid-cols-12 gap-6" style={{ minHeight: 480 }}>
                <div className="col-span-12 lg:col-span-4">
                  <AddPanel onAddFiles={handleAddFiles} onAddYouTube={handleAddYouTube} t={t} />
                </div>
                <div className="col-span-12 lg:col-span-8">
                  <TrackList
                    tracks={tracks}
                    currentId={player.currentId}
                    isPlaying={player.isPlaying}
                    onPlay={player.play}
                    onDelete={handleDelete}
                    onRename={handleRename}
                    onReorder={handleReorder}
                    t={t}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="text-center mt-6">
            <div className="font-amiri text-[15px]" style={{ color: '#D89274' }}>
              هديّة من رويـدا و عبدالرحمن
            </div>
          </div>
        </div>

        <PlayerBar
          tracks={tracks}
          currentId={player.currentId}
          isPlaying={player.isPlaying}
          position={player.position}
          duration={player.duration}
          volume={player.volume}
          muted={player.muted}
          shuffle={shuffle}
          repeat={repeat}
          onPlayPause={player.toggle}
          onPrev={goPrev}
          onNext={goNext}
          onSeek={player.seek}
          onVolume={player.setVolume}
          onToggleMute={player.toggleMute}
          onToggleShuffle={() => setShuffle(s => !s)}
          onToggleRepeat={() => setRepeat(r => !r)}
          t={t}
        />

        <div className="youtube-host"><div id={player.ytHostId} /></div>

        {toast && <div className="toast">{toast}</div>}
      </div>
    </div>
  );
}
