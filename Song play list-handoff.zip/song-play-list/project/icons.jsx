// icons.jsx — minimal stroke icons matching the wedding aesthetic
const Icon = ({ d, size = 18, fill = 'none', stroke = 'currentColor', sw = 1.5, children }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke={stroke}
       strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">
    {children || <path d={d} />}
  </svg>
);

const IconPlay  = (p) => <Icon {...p} fill="currentColor" stroke="none"><path d="M7 5.5v13l11-6.5z" /></Icon>;
const IconPause = (p) => <Icon {...p}><path d="M8 5v14M16 5v14" /></Icon>;
const IconPrev  = (p) => <Icon {...p}><path d="M7 5v14M19 5l-9 7 9 7z" fill="currentColor" stroke="currentColor" /></Icon>;
const IconNext  = (p) => <Icon {...p}><path d="M17 5v14M5 5l9 7-9 7z" fill="currentColor" stroke="currentColor" /></Icon>;
const IconVol   = (p) => <Icon {...p}><path d="M4 9v6h4l5 4V5L8 9H4z" /><path d="M16 8.5a4.5 4.5 0 0 1 0 7" /><path d="M18.5 6a8 8 0 0 1 0 12" /></Icon>;
const IconMute  = (p) => <Icon {...p}><path d="M4 9v6h4l5 4V5L8 9H4z" /><path d="M16 9l5 6M21 9l-5 6" /></Icon>;
const IconUpload= (p) => <Icon {...p}><path d="M12 16V4M7 9l5-5 5 5" /><path d="M5 18h14" /></Icon>;
const IconYT    = (p) => <Icon {...p}><rect x="2.5" y="6" width="19" height="12" rx="3" /><path d="M10 9.5v5l4.5-2.5z" fill="currentColor" stroke="currentColor" /></Icon>;
const IconImport= (p) => <Icon {...p}><path d="M12 4v12M7 11l5 5 5-5" /><path d="M5 20h14" /></Icon>;
const IconExport= (p) => <Icon {...p}><path d="M12 20V8M7 13l5-5 5 5" /><path d="M5 4h14" /></Icon>;
const IconTrash = (p) => <Icon {...p}><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13" /></Icon>;
const IconEdit  = (p) => <Icon {...p}><path d="M4 20h4l11-11-4-4L4 16v4z" /></Icon>;
const IconDrag  = (p) => <Icon {...p}><circle cx="9" cy="6"  r="1.2" fill="currentColor" stroke="none"/><circle cx="9" cy="12" r="1.2" fill="currentColor" stroke="none"/><circle cx="9" cy="18" r="1.2" fill="currentColor" stroke="none"/><circle cx="15" cy="6"  r="1.2" fill="currentColor" stroke="none"/><circle cx="15" cy="12" r="1.2" fill="currentColor" stroke="none"/><circle cx="15" cy="18" r="1.2" fill="currentColor" stroke="none"/></Icon>;
const IconPlus  = (p) => <Icon {...p}><path d="M12 5v14M5 12h14" /></Icon>;
const IconClose = (p) => <Icon {...p}><path d="M6 6l12 12M18 6L6 18" /></Icon>;
const IconCheck = (p) => <Icon {...p}><path d="M5 12l5 5L20 7" /></Icon>;
const IconMusic = (p) => <Icon {...p}><path d="M9 18V6l10-2v12" /><circle cx="6" cy="18" r="2.5" fill="currentColor" stroke="currentColor" /><circle cx="16" cy="16" r="2.5" fill="currentColor" stroke="currentColor" /></Icon>;
const IconGlobe = (p) => <Icon {...p}><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18" /></Icon>;
const IconSparkle = (p) => <Icon {...p}><path d="M12 4l1.5 4.5L18 10l-4.5 1.5L12 16l-1.5-4.5L6 10l4.5-1.5z" fill="currentColor" stroke="currentColor" /></Icon>;
const IconShuffle = (p) => <Icon {...p}><path d="M3 6h4l10 12h4M3 18h4L17 6h4M18 3l3 3-3 3M18 15l3 3-3 3" /></Icon>;
const IconRepeat  = (p) => <Icon {...p}><path d="M17 1l4 4-4 4M3 11V9a4 4 0 0 1 4-4h14M7 23l-4-4 4-4M21 13v2a4 4 0 0 1-4 4H3" /></Icon>;

window.WPIcons = {
  IconPlay, IconPause, IconPrev, IconNext, IconVol, IconMute,
  IconUpload, IconYT, IconImport, IconExport, IconTrash, IconEdit,
  IconDrag, IconPlus, IconClose, IconCheck, IconMusic, IconGlobe,
  IconSparkle, IconShuffle, IconRepeat,
};
