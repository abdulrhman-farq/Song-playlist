// ── lib.js — storage, persistence, helpers ──────────────────────────────
// Plain JS (not Babel JSX) so we can load it eagerly.

(function (global) {
  'use strict';

  // ── IndexedDB for audio blobs ─────────────────────────────────────────
  const DB_NAME = 'wedding-playlist';
  const DB_VERSION = 1;
  const STORE = 'blobs';

  function openDB() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async function putBlob(key, blob) {
    const db = await openDB();
    return new Promise((res, rej) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put(blob, key);
      tx.oncomplete = () => res();
      tx.onerror = () => rej(tx.error);
    });
  }

  async function getBlob(key) {
    const db = await openDB();
    return new Promise((res, rej) => {
      const tx = db.transaction(STORE, 'readonly');
      const r = tx.objectStore(STORE).get(key);
      r.onsuccess = () => res(r.result || null);
      r.onerror = () => rej(r.error);
    });
  }

  async function deleteBlob(key) {
    const db = await openDB();
    return new Promise((res, rej) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).delete(key);
      tx.oncomplete = () => res();
      tx.onerror = () => rej(tx.error);
    });
  }

  async function clearBlobs() {
    const db = await openDB();
    return new Promise((res, rej) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).clear();
      tx.oncomplete = () => res();
      tx.onerror = () => rej(tx.error);
    });
  }

  // ── localStorage for metadata ─────────────────────────────────────────
  const META_KEY = 'wedding-playlist:v1';

  function loadMeta() {
    try {
      const raw = localStorage.getItem(META_KEY);
      if (!raw) return null;
      return JSON.parse(raw);
    } catch (e) { return null; }
  }
  function saveMeta(data) {
    try { localStorage.setItem(META_KEY, JSON.stringify(data)); } catch (e) {}
  }

  // ── Helpers ───────────────────────────────────────────────────────────
  function uid() {
    return 't_' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
  }

  function fmtTime(sec) {
    if (sec == null || isNaN(sec) || !isFinite(sec)) return '—:—';
    sec = Math.max(0, Math.floor(sec));
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return m + ':' + String(s).padStart(2, '0');
  }

  // Extract YouTube video ID from any common URL form
  function parseYouTubeId(url) {
    if (!url || typeof url !== 'string') return null;
    url = url.trim();
    // direct id
    if (/^[A-Za-z0-9_-]{11}$/.test(url)) return url;
    try {
      const u = new URL(url);
      if (u.hostname.includes('youtu.be')) {
        const id = u.pathname.replace(/^\//, '').split('/')[0];
        return /^[A-Za-z0-9_-]{11}$/.test(id) ? id : null;
      }
      if (u.hostname.includes('youtube.com') || u.hostname.includes('music.youtube.com')) {
        const v = u.searchParams.get('v');
        if (v && /^[A-Za-z0-9_-]{11}$/.test(v)) return v;
        // /embed/<id>  or  /shorts/<id>
        const m = u.pathname.match(/\/(embed|shorts)\/([A-Za-z0-9_-]{11})/);
        if (m) return m[2];
      }
    } catch (e) { /* ignore */ }
    return null;
  }

  function ytThumb(id) {
    return id ? `https://i.ytimg.com/vi/${id}/hqdefault.jpg` : null;
  }

  // Read duration from an audio Blob in the background
  function probeAudioDuration(blob) {
    return new Promise((resolve) => {
      const url = URL.createObjectURL(blob);
      const a = new Audio();
      a.preload = 'metadata';
      a.src = url;
      const cleanup = () => { URL.revokeObjectURL(url); };
      a.onloadedmetadata = () => {
        const d = a.duration;
        cleanup();
        resolve(isFinite(d) ? d : null);
      };
      a.onerror = () => { cleanup(); resolve(null); };
      // safety timeout
      setTimeout(() => { cleanup(); resolve(null); }, 8000);
    });
  }

  // Friendly fallback title from filename
  function titleFromFilename(name) {
    if (!name) return 'Untitled';
    return name.replace(/\.[^.]+$/, '').replace(/[_\-]+/g, ' ').trim() || 'Untitled';
  }

  // Export to lib namespace
  global.WP = {
    putBlob, getBlob, deleteBlob, clearBlobs,
    loadMeta, saveMeta,
    uid, fmtTime,
    parseYouTubeId, ytThumb,
    probeAudioDuration, titleFromFilename,
  };
})(window);
