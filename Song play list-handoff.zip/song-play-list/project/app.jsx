// app.jsx — Wedding Playlist root
const { useState: uS, useEffect: uE, useRef: uR, useCallback: uC, useMemo: uM } = React;
const WP = window.WP;
const STRINGS = window.WP_STRINGS;
const PlayerBar = window.WPPlayerBar;
const loadYouTubeAPI = window.WPLoadYouTubeAPI;
const Header = window.WPHeader;
const AddPanel = window.WPAddPanel;
const TrackRow = window.WPTrackRow;

// ── Sample tracks (loaded on demand) ──────────────────────────────────────
function makeSamples(t) {
  return [
    { id: WP.uid(), source: 'youtube', title: 'الزفّة — Wedding Procession', youtubeId: 'TpiUmTYqxk0', url: 'https://www.youtube.com/watch?v=TpiUmTYqxk0', duration: null, note: 'sample · ceremony' },
    { id: WP.uid(), source: 'youtube', title: 'Canon in D — Pachelbel',       youtubeId: 'NlprozGcs80', url: 'https://www.youtube.com/watch?v=NlprozGcs80', duration: null, note: 'sample · classical' },
    { id: WP.uid(), source: 'youtube', title: 'A Thousand Years — Acoustic',  youtubeId: 'rtOvBOTyX00', url: 'https://www.youtube.com/watch?v=rtOvBOTyX00', duration: null, note: 'sample · reception' },
  ];
}

function App() {
  // ── Language / direction ────────────────────────────────────────────────
  const [lang, setLang] = uS(() => (localStorage.getItem('wp:lang') || 'en'));
  uE(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = STRINGS[lang].direction;
    localStorage.setItem('wp:lang', lang);
  }, [lang]);
  const t = STRINGS[lang];
  const dir = STRINGS[lang].direction;

  // ── Playlist state ──────────────────────────────────────────────────────
  const [playlistName, setPlaylistName] = uS(t.untitled);
  const [tracks, setTracks] = uS([]);  // {id, source, title, youtubeId?, url?, blobKey?, duration, note?}
  const [currentId, setCurrentId] = uS(null);
  const [isPlaying, setIsPlaying] = uS(false);
  const [position, setPosition] = uS(0);
  const [duration, setDuration] = uS(0);
  const [volume, setVolume] = uS(0.8);
  const [muted, setMuted] = uS(false);
  const [autoplay, setAutoplay] = uS(true);
  const [shuffle, setShuffle] = uS(false);
  const [repeat, setRepeat] = uS(false);
  const [toast, setToast] = uS(null);
  const [loaded, setLoaded] = uS(false);

  // object-URL cache for uploaded blobs
  const audioUrlCache = uR({}); // {blobKey: objectURL}
  const audioRef = uR(null);    // HTMLAudioElement
  const ytPlayerRef = uR(null); // YT.Player
  const ytPollRef = uR(null);   // interval

  // ── Load saved state on mount ───────────────────────────────────────────
  uE(() => {
    const saved = WP.loadMeta();
    if (saved) {
      setPlaylistName(saved.name || t.untitled);
      setTracks(Array.isArray(saved.tracks) ? saved.tracks : []);
      if (saved.volume != null) setVolume(saved.volume);
      if (saved.autoplay != null) setAutoplay(saved.autoplay);
      if (saved.shuffle != null) setShuffle(saved.shuffle);
      if (saved.repeat != null) setRepeat(saved.repeat);
    }
    setLoaded(true);
  }, []);

  // Persist metadata (NOT blobs — those live in IndexedDB)
  uE(() => {
    if (!loaded) return;
    const safeTracks = tracks.map(x => ({
      id: x.id, source: x.source, title: x.title,
      youtubeId: x.youtubeId, url: x.url,
      blobKey: x.blobKey, blobName: x.blobName,
      duration: x.duration, note: x.note,
    }));
    WP.saveMeta({ name: playlistName, tracks: safeTracks, volume, autoplay, shuffle, repeat });
  }, [loaded, playlistName, tracks, volume, autoplay, shuffle, repeat]);

  // ── Toast helper ────────────────────────────────────────────────────────
  function flash(msg) {
    setToast(msg);
    clearTimeout(flash._t);
    flash._t = setTimeout(() => setToast(null), 2200);
  }

  // ── Object URL helper for uploaded audio ────────────────────────────────
  async function getAudioUrl(track) {
    if (!track.blobKey) return null;
    if (audioUrlCache.current[track.blobKey]) return audioUrlCache.current[track.blobKey];
    const blob = await WP.getBlob(track.blobKey);
    if (!blob) return null;
    const url = URL.createObjectURL(blob);
    audioUrlCache.current[track.blobKey] = url;
    return url;
  }

  // Revoke URLs on unmount
  uE(() => () => {
    Object.values(audioUrlCache.current).forEach(u => URL.revokeObjectURL(u));
  }, []);

  // ── Add files ───────────────────────────────────────────────────────────
  async function handleAddFiles(files) {
    const added = [];
    for (const file of files) {
      const blobKey = 'b_' + WP.uid();
      await WP.putBlob(blobKey, file);
      const dur = await WP.probeAudioDuration(file);
      added.push({
        id: WP.uid(),
        source: 'upload',
        title: WP.titleFromFilename(file.name),
        blobKey, blobName: file.name,
        duration: dur,
        note: file.name,
      });
    }
    setTracks(prev => [...prev, ...added]);
    flash(`+ ${added.length} ${added.length === 1 ? t.track : t.tracks}`);
  }

  // ── Add YouTube ─────────────────────────────────────────────────────────
  function handleAddYouTube({ id, url, title }) {
    const newTrack = {
      id: WP.uid(),
      source: 'youtube',
      title: title || `YouTube · ${id}`,
      youtubeId: id,
      url,
      duration: null,
    };
    setTracks(prev => [...prev, newTrack]);
    flash('+ ' + (title || 'YouTube'));
  }

  // ── Sample loader ───────────────────────────────────────────────────────
  function handleLoadSamples() {
    const s = makeSamples(t);
    setTracks(prev => [...prev, ...s]);
    flash('+ ' + s.length + ' ' + t.tracks);
  }

  // ── Delete / rename / reorder ───────────────────────────────────────────
  async function handleDelete(id) {
    const tr = tracks.find(x => x.id === id);
    if (tr && tr.blobKey) {
      await WP.deleteBlob(tr.blobKey).catch(() => {});
      if (audioUrlCache.current[tr.blobKey]) {
        URL.revokeObjectURL(audioUrlCache.current[tr.blobKey]);
        delete audioUrlCache.current[tr.blobKey];
      }
    }
    setTracks(prev => prev.filter(x => x.id !== id));
    if (currentId === id) {
      stopPlayback();
      setCurrentId(null);
    }
  }

  function handleRename(id, title) {
    setTracks(prev => prev.map(x => x.id === id ? {...x, title} : x));
  }

  function moveTrack(fromId, toId, pos) {
    setTracks(prev => {
      const from = prev.findIndex(x => x.id === fromId);
      const to   = prev.findIndex(x => x.id === toId);
      if (from < 0 || to < 0 || from === to) return prev;
      const next = prev.slice();
      const [moved] = next.splice(from, 1);
      let insertAt = next.findIndex(x => x.id === toId);
      if (pos === 'below') insertAt += 1;
      next.splice(insertAt, 0, moved);
      return next;
    });
  }

  async function handleClearAll() {
    if (!confirm(t.confirmClear)) return;
    await WP.clearBlobs();
    Object.values(audioUrlCache.current).forEach(u => URL.revokeObjectURL(u));
    audioUrlCache.current = {};
    stopPlayback();
    setCurrentId(null);
    setTracks([]);
  }

  // ── Import / Export ─────────────────────────────────────────────────────
  function handleExport() {
    const data = {
      _meta: { app: 'wedding-playlist', version: 1, exportedAt: new Date().toISOString() },
      name: playlistName,
      tracks: tracks
        .filter(x => x.source === 'youtube')   // uploaded blobs can't travel
        .map(x => ({ id: x.id, source: x.source, title: x.title, youtubeId: x.youtubeId, url: x.url, duration: x.duration, note: x.note })),
      stats: {
        uploadedSkipped: tracks.filter(x => x.source === 'upload').length,
      }
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = (playlistName || 'wedding-playlist').replace(/[^\w\u0600-\u06FF\-]+/g, '_') + '.json';
    a.click();
    URL.revokeObjectURL(url);
    flash('JSON exported');
  }

  function handleImport() {
    const inp = document.createElement('input');
    inp.type = 'file';
    inp.accept = 'application/json,.json';
    inp.onchange = async () => {
      const f = inp.files && inp.files[0];
      if (!f) return;
      try {
        const text = await f.text();
        const data = JSON.parse(text);
        if (data.name) setPlaylistName(data.name);
        if (Array.isArray(data.tracks)) {
          const incoming = data.tracks.map(x => ({
            id: WP.uid(),
            source: x.source === 'upload' ? 'upload' : 'youtube',
            title: x.title || 'Untitled',
            youtubeId: x.youtubeId, url: x.url,
            duration: x.duration || null,
            note: x.note,
          })).filter(x => x.source === 'youtube' && x.youtubeId);
          setTracks(prev => [...prev, ...incoming]);
          flash('+ ' + incoming.length + ' ' + t.tracks);
        }
      } catch (e) { alert(t.importErr); }
    };
    inp.click();
  }

  // ── Playback engine ─────────────────────────────────────────────────────
  function stopPlayback() {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = '';
    }
    if (ytPlayerRef.current && ytPlayerRef.current.stopVideo) {
      try { ytPlayerRef.current.stopVideo(); } catch(e) {}
    }
    clearInterval(ytPollRef.current);
    setIsPlaying(false);
    setPosition(0);
    setDuration(0);
  }

  // Switch current track
  uE(() => {
    if (!currentId) return;
    const track = tracks.find(x => x.id === currentId);
    if (!track) return;

    // tear down previous
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = '';
    }
    if (ytPlayerRef.current && ytPlayerRef.current.stopVideo) {
      try { ytPlayerRef.current.stopVideo(); } catch(e) {}
    }
    clearInterval(ytPollRef.current);
    setPosition(0);

    if (track.source === 'upload') {
      (async () => {
        const url = await getAudioUrl(track);
        if (!url) { flash('Audio missing'); return; }
        const a = audioRef.current;
        a.src = url;
        a.volume = muted ? 0 : volume;
        try { await a.play(); setIsPlaying(true); }
        catch (e) { setIsPlaying(false); }
      })();
    } else if (track.source === 'youtube' && track.youtubeId) {
      (async () => {
        const YT = await loadYouTubeAPI();
        if (!ytPlayerRef.current) {
          ytPlayerRef.current = new YT.Player('yt-host', {
            height: '1', width: '1',
            videoId: track.youtubeId,
            playerVars: { autoplay: 1, controls: 0, modestbranding: 1, rel: 0, playsinline: 1 },
            events: {
              onReady: (e) => {
                e.target.setVolume(Math.round((muted ? 0 : volume) * 100));
                e.target.playVideo();
                startYTPoll();
              },
              onStateChange: (e) => {
                if (e.data === YT.PlayerState.PLAYING) setIsPlaying(true);
                else if (e.data === YT.PlayerState.PAUSED) setIsPlaying(false);
                else if (e.data === YT.PlayerState.ENDED) handleTrackEnded();
                if (e.data === YT.PlayerState.PLAYING || e.data === YT.PlayerState.BUFFERING) {
                  const d = e.target.getDuration();
                  if (d) {
                    setDuration(d);
                    // Patch the track's duration once known
                    setTracks(prev => prev.map(x => x.id === track.id && !x.duration ? {...x, duration: d} : x));
                  }
                }
              },
            }
          });
        } else {
          ytPlayerRef.current.loadVideoById(track.youtubeId);
          ytPlayerRef.current.setVolume(Math.round((muted ? 0 : volume) * 100));
          startYTPoll();
        }
      })();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentId]);

  function startYTPoll() {
    clearInterval(ytPollRef.current);
    ytPollRef.current = setInterval(() => {
      const p = ytPlayerRef.current;
      if (!p || !p.getCurrentTime) return;
      try {
        setPosition(p.getCurrentTime() || 0);
        const d = p.getDuration();
        if (d) setDuration(d);
      } catch (e) {}
    }, 400);
  }

  // HTML5 audio events
  uE(() => {
    if (audioRef.current) return;
    const a = new Audio();
    a.preload = 'metadata';
    a.addEventListener('timeupdate', () => setPosition(a.currentTime));
    a.addEventListener('loadedmetadata', () => {
      setDuration(a.duration || 0);
      if (currentIdRef.current) {
        const trkId = currentIdRef.current;
        setTracks(prev => prev.map(x => x.id === trkId && !x.duration ? {...x, duration: a.duration} : x));
      }
    });
    a.addEventListener('play',  () => setIsPlaying(true));
    a.addEventListener('pause', () => setIsPlaying(false));
    a.addEventListener('ended', () => handleTrackEnded());
    audioRef.current = a;
  }, []);

  // Mirror currentId to a ref for use inside audio event listeners
  const currentIdRef = uR(null);
  uE(() => { currentIdRef.current = currentId; }, [currentId]);

  // ── Volume / mute live update ───────────────────────────────────────────
  uE(() => {
    const v = muted ? 0 : volume;
    if (audioRef.current) audioRef.current.volume = v;
    if (ytPlayerRef.current && ytPlayerRef.current.setVolume) {
      try { ytPlayerRef.current.setVolume(Math.round(v * 100)); } catch(e) {}
    }
  }, [volume, muted]);

  // ── Transport handlers ──────────────────────────────────────────────────
  function handlePlay(id) {
    if (id === currentId) {
      handlePlayPause();
    } else {
      setCurrentId(id);
    }
  }

  function handlePlayPause() {
    if (!currentId) {
      if (tracks.length) setCurrentId(tracks[0].id);
      return;
    }
    const track = tracks.find(x => x.id === currentId);
    if (!track) return;
    if (track.source === 'upload') {
      const a = audioRef.current;
      if (a.paused) a.play().catch(()=>{});
      else a.pause();
    } else {
      const p = ytPlayerRef.current;
      if (!p) return;
      const state = p.getPlayerState && p.getPlayerState();
      if (state === 1) p.pauseVideo();
      else p.playVideo();
    }
  }

  function nextIndex(currIdx, dir = 1) {
    if (tracks.length === 0) return -1;
    if (shuffle && dir > 0) {
      // pick a different random track
      if (tracks.length === 1) return 0;
      let n;
      do { n = Math.floor(Math.random() * tracks.length); } while (n === currIdx);
      return n;
    }
    let n = currIdx + dir;
    if (n < 0) n = tracks.length - 1;
    if (n >= tracks.length) n = 0;
    return n;
  }

  function handleNext() {
    const i = tracks.findIndex(x => x.id === currentId);
    const n = nextIndex(i, 1);
    if (n >= 0) setCurrentId(tracks[n].id);
  }
  function handlePrev() {
    const i = tracks.findIndex(x => x.id === currentId);
    const n = nextIndex(i, -1);
    if (n >= 0) setCurrentId(tracks[n].id);
  }
  function handleTrackEnded() {
    if (repeat) {
      // re-seek to 0 and play
      const t = tracks.find(x => x.id === currentId);
      if (!t) return;
      if (t.source === 'upload') { audioRef.current.currentTime = 0; audioRef.current.play().catch(()=>{}); }
      else { try { ytPlayerRef.current.seekTo(0, true); ytPlayerRef.current.playVideo(); } catch(e) {} }
      return;
    }
    if (autoplay) handleNext();
    else setIsPlaying(false);
  }

  function handleSeek(s) {
    setPosition(s);
    const t = tracks.find(x => x.id === currentId);
    if (!t) return;
    if (t.source === 'upload') { audioRef.current.currentTime = s; }
    else { try { ytPlayerRef.current.seekTo(s, true); } catch(e) {} }
  }

  // ── Drag and drop state ─────────────────────────────────────────────────
  const [dragOverId, setDragOverId] = uS(null);
  const [dropPos, setDropPos]       = uS(null);
  const dragIdRef = uR(null);

  function onDragStart(e, id) {
    dragIdRef.current = id;
    e.dataTransfer.effectAllowed = 'move';
    try { e.dataTransfer.setData('text/plain', id); } catch(e2) {}
  }
  function onDragOver(e, id) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    const rect = e.currentTarget.getBoundingClientRect();
    const above = (e.clientY - rect.top) < rect.height / 2;
    setDragOverId(id);
    setDropPos(above ? 'above' : 'below');
  }
  function onDragLeave(e, id) {
    if (dragOverId === id) {
      setDragOverId(null);
      setDropPos(null);
    }
  }
  function onDrop(e, id) {
    e.preventDefault();
    const fromId = dragIdRef.current;
    if (!fromId || fromId === id) return;
    moveTrack(fromId, id, dropPos);
    dragIdRef.current = null;
    setDragOverId(null);
    setDropPos(null);
  }

  // ── Derived stats ───────────────────────────────────────────────────────
  const totalSeconds = uM(() => tracks.reduce((s, x) => s + (Number.isFinite(x.duration) ? x.duration : 0), 0), [tracks]);

  // ── Render ──────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen relative">
      {/* Soft champagne background */}
      <div className="fixed inset-0" style={{
        background: 'radial-gradient(ellipse 80% 50% at 50% 0%, #F4ECDF 0%, #EBE0CE 50%, #E5D5BC 100%)'
      }} />

      <div className="relative">
        <div className="mx-auto max-w-7xl px-6 py-8" style={{paddingBottom: 140}}>

          {/* Card stage */}
          <div className="stage-card paper-bg p-2">
            <div style={{position: 'relative', zIndex: 1}}>
              <Header
                playlistName={playlistName}
                onRename={setPlaylistName}
                t={t} dir={dir} lang={lang}
                onToggleLang={() => setLang(l => l === 'ar' ? 'en' : 'ar')}
                onImport={handleImport}
                onExport={handleExport}
                onSamples={handleLoadSamples}
                onClearAll={handleClearAll}
                hasTracks={tracks.length > 0}
              />

              <div className="px-8 pb-8 grid grid-cols-12 gap-6" style={{minHeight: 480}}>
                {/* Left: add */}
                <div className="col-span-12 lg:col-span-4">
                  <AddPanel
                    onAddFiles={handleAddFiles}
                    onAddYouTube={handleAddYouTube}
                    t={t} dir={dir}
                  />
                </div>

                {/* Right: tracks */}
                <div className="col-span-12 lg:col-span-8">
                  <div className="stage-card p-6">
                    <div className="flex items-baseline justify-between mb-4 px-1">
                      <div className="label-tracked">
                        {tracks.length} {tracks.length === 1 ? t.track : t.tracks}
                      </div>
                      <div className="label-tracked">
                        {t.total} · <span className="tnum" style={{fontVariantNumeric:'tabular-nums', color:'#3A2C20'}}>{WP.fmtTime(totalSeconds)}</span>
                      </div>
                    </div>

                    {tracks.length === 0 ? (
                      <div className="text-center py-16 px-6">
                        <div className="inline-flex items-center justify-center rounded-full mb-4" style={{width: 72, height: 72, background: 'rgba(216,146,116,0.10)', border: '0.5px solid rgba(216,146,116,0.30)'}}>
                          <span style={{color:'#D89274'}}>♪</span>
                        </div>
                        <div className="font-italiana text-[28px]" style={{color:'#D89274'}}>{t.addFirst}</div>
                        <div className="font-cormorant text-[16px] mt-2 max-w-md mx-auto" style={{color:'#6B4A35', lineHeight: 1.5, fontStyle:'italic'}}>
                          {t.emptyHint}
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-col gap-2">
                        {tracks.map((tr, i) => (
                          <TrackRow
                            key={tr.id}
                            track={tr} idx={i}
                            isCurrent={tr.id === currentId}
                            isPlaying={tr.id === currentId && isPlaying}
                            onPlay={handlePlay}
                            onDelete={handleDelete}
                            onRename={(v) => handleRename(tr.id, v)}
                            onDragStart={onDragStart}
                            onDragOver={onDragOver}
                            onDragLeave={onDragLeave}
                            onDrop={onDrop}
                            dropPos={dragOverId === tr.id ? dropPos : null}
                            t={t} dir={dir}
                          />
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Footer caption */}
          <div className="text-center mt-6">
            <div className="font-amiri text-[15px]" style={{color: '#D89274'}}>هديّة من رويـدا و عبدالرحمن</div>
          </div>
        </div>

        {/* Player bar */}
        <PlayerBar
          tracks={tracks}
          currentId={currentId}
          isPlaying={isPlaying}
          position={position}
          duration={duration}
          volume={volume}
          muted={muted}
          autoplay={autoplay}
          repeat={repeat}
          shuffle={shuffle}
          onPlayPause={handlePlayPause}
          onPrev={handlePrev}
          onNext={handleNext}
          onSeek={handleSeek}
          onVolume={(v) => { setVolume(v); setMuted(false); }}
          onToggleMute={() => setMuted(m => !m)}
          onToggleAutoplay={() => setAutoplay(a => !a)}
          onToggleRepeat={() => setRepeat(r => !r)}
          onToggleShuffle={() => setShuffle(s => !s)}
          t={t} dir={dir}
        />

        {/* Hidden YouTube host */}
        <div className="youtube-host"><div id="yt-host"></div></div>

        {/* Toast */}
        {toast && <div className="toast">{toast}</div>}
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
